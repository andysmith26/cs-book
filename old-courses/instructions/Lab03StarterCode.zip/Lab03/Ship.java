import greenfoot.*;

/**
 * Write a description of class Ship here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class Ship extends Actor
{
    /**
     * Constructor for objects of class Ship
     */
    public Ship()
    {   
    }
    
    public void act()
    {    
    }
}
